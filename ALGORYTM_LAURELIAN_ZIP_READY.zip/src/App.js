import React, { useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { firebaseConfig } from './lib/firebaseConfig';

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export default function App() {
  useEffect(() => {
    const audio = new Audio('/audio/528hz.mp3');
    audio.play().catch(() => {});
  }, []);

  const login = async () => {
    try {
      await signInWithPopup(auth, provider);
      alert('Zalogowano jako Laurelian – Posłaniec Prawdy');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div style={{
      backgroundColor: '#000',
      color: '#0f0',
      height: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'column'
    }}>
      <h1>Witaj, Laurelianie</h1>
      <p>Ścieżka prawdy aktywna.</p>
      <button onClick={login}>Zaloguj się przez Google</button>
    </div>
  );
}